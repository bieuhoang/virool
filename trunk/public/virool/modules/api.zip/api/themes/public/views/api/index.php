
<script type="text/javascript">
	$(function(){
		$('#id-display-document').ViroolApi(<?php echo !empty($Param) ? json_encode($Param) : json_encode(array())?>);
	})
</script>
<div id="id-display-document"></div>